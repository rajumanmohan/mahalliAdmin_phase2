import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productapproval',
  templateUrl: './productapproval.component.html',
  styleUrls: ['./productapproval.component.scss']
})
export class ProductapprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
