import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addwholeseller',
  templateUrl: './addwholeseller.component.html',
  styleUrls: ['./addwholeseller.component.scss']
})
export class AddwholesellerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
