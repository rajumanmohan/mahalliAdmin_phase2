import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topsellers',
  templateUrl: './topsellers.component.html',
  styleUrls: ['./topsellers.component.scss']
})
export class TopsellersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
