import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { AppService } from './../../services/mahali/mahali-data.service';
import 'chartjs-plugin-annotation';


import { DatePipe } from '@angular/common';


@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent implements OnInit {

  public UserOrd: number[];

  datearr = [];
  OneArr = [];
  graphData = [];
  UserData = localStorage.user_orders;
  constructor(private appService: AppService, public router: Router, private datePipe: DatePipe) {
    // this.test();
    this.router.navigate(['/dashboard']);
    // this.UserData = localStorage.user_orders;
  }

  ngOnInit(): void {
    console.log([this.UserData])
    // this.getOneMonthDays();
    // this.testMonths();
    this.getWeekChartsMethod();
    // this.reload();
    // this.getGraph();
    // this.role = sessionStorage.role;
    // this.getAdminCount();
    // generate random values for mainChart
    // for (let i = 0; i <= this.mainChartElements; i++) {
    //   this.mainChartData1.push(this.random(50, 200));
    //   this.mainChartData2.push(this.random(80, 100));
    //   // this.mainChartData3.push(65);
    //   if (sessionStorage.role == 'wholesaler') {
    //     this.getWholeProddsCunt();
    //   } else {
    //     this.getvendorCount();
    //   }
    // }
  }
  @ViewChild('myCanvas');
  public canvas: ElementRef;
  public context: CanvasRenderingContext2D;
  public chartType: string = 'line';
  public chartData: any[];
  public chartLabels: any[];
  public chartColors: any[];
  public chartOptions: any;
  radioModel: string = 'Month';
  wholeCount = [];
  venCount: [];
  user_orders: any;
  UserOrder = [];
  vendor_orders = [];
  testArr = [];



  firstday = '';
  secondday = '';
  thirdday = '';
  fourthday = '';
  fifthday = '';
  sixthday = '';

  lastday = '';

  verylastday = '';
  getWeekChartsMethod() {
    var curr = new Date; // get current date
    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week

    var varylast1 = first + 7; // last day is the first day + 6
    var last = first + 6; // last day is the first day + 6
    var lasttosecond = first + 5; // last day is the first day + 6
    var lasttothird = first + 4; // last day is the first day + 6

    var lasttofouth = first + 3; // last day is the first day + 6

    var lasttofifth = first + 2; // last day is the first day + 6
    var lasttosixth = first + 1; // last day is the first day + 6
    this.firstday = new Date(curr.setDate(first)).toUTCString();
    this.secondday = new Date(curr.setDate(lasttosixth)).toUTCString();
    this.thirdday = new Date(curr.setDate(lasttofifth)).toUTCString();
    this.fourthday = new Date(curr.setDate(lasttofouth)).toUTCString();
    this.fifthday = new Date(curr.setDate(lasttothird)).toUTCString();
    this.sixthday = new Date(curr.setDate(lasttosecond)).toUTCString();
    this.lastday = new Date(curr.setDate(last)).toUTCString();
    this.verylastday = new Date(curr.setDate(varylast1)).toUTCString();
    var firstdayOne = this.datePipe.transform(this.firstday, "yyyy/MM/dd");
    var seconddayOne = this.datePipe.transform(this.secondday, "yyyy/MM/dd");

    var thirddayOne = this.datePipe.transform(this.thirdday, "yyyy/MM/dd");

    var fourthdayOne = this.datePipe.transform(this.fourthday, "yyyy/MM/dd");

    var fifthdayOne = this.datePipe.transform(this.fifthday, "yyyy/MM/dd");

    var sixthdayOne = this.datePipe.transform(this.sixthday, "yyyy/MM/dd");

    var lastdayOne = this.datePipe.transform(this.lastday, "yyyy/MM/dd");

    var verylastdayOne = this.datePipe.transform(this.verylastday, "yyyy/MM/dd");
    var arr = {
      "array": [{ "startdate": firstdayOne, "enddate": seconddayOne },
      { "startdate": seconddayOne, "enddate": thirddayOne },
      { "startdate": thirddayOne, "enddate": fourthdayOne },
      { "startdate": fourthdayOne, "enddate": fifthdayOne },
      { "startdate": fifthdayOne, "enddate": sixthdayOne },
      { "startdate": sixthdayOne, "enddate": lastdayOne },
      { "startdate": lastdayOne, "enddate": verylastdayOne }],
      "type": 0
    }
    this.testArr = [firstdayOne, seconddayOne, thirddayOne, fourthdayOne, fifthdayOne, sixthdayOne, lastdayOne]
    console.log(this.testArr);
    arr.array.forEach((element) => {
      if (this.datearr.length < arr.array.length) {
        this.datearr.push(element.startdate)
      }
    });
    this.appService.getGraph(arr).subscribe((res: any) => {
      this.graphData = res;
      this.user_orders = res.user_orders;
      this.UserOrder = this.user_orders;
      localStorage.setItem("user_orders", JSON.stringify(res.user_orders));
      this.vendor_orders = res.vendor_orders;
    });

    this.UserOrd = JSON.parse(localStorage.user_orders);


    this.chartData = [{
      data: [this.UserOrd.toString()],
      label: 'Anthracnose',
      fill: false
    },
    {
      data: [7, 1, 4, 7, 8],
      label: 'Anthracnose',
      fill: false
    }];
    this.chartLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May'];
    this.chartColors = [{
      backgroundColor: 'rgba(0, 0, 0, 0.2)',
      borderColor: 'rgba(0, 0, 0, 1)'
    }];
    this.chartOptions = {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true,
            stepSize: 1
          }
        }]
      },
      annotation: {
        drawTime: 'beforeDatasetsDraw',
        annotations: [{
          type: 'box',
          id: 'a-box-1',
          yScaleID: 'y-axis-0',
          yMin: 0,
          yMax: 1,
          backgroundColor: '#4cf03b'
        }, {
          type: 'box',
          id: 'a-box-2',
          yScaleID: 'y-axis-0',
          yMin: 1,
          yMax: 2.7,
          backgroundColor: '#fefe32'
        }, {
          type: 'box',
          id: 'a-box-3',
          yScaleID: 'y-axis-0',
          yMin: 2.7,
          yMax: 5,
          backgroundColor: '#fe3232'
        }]
      }
    }
  };


}
  // mainChart
  // public mainChartElements = 27;
  // public mainChartData1: Array<number> = [];
  // public mainChartData2: Array<number> = [];
  // // public mainChartData3: Array<number> = [];
  // public mainChartData: Array<any> = [
  //   {
  //     data: [1, 2, 1, 2, 4],
  //     label: 'User Orders',
  //   },
  //   {
  //     data: [this.UserData.toString()],
  //     label: 'Vendor Orders'
  //   },
  //   // console.log([this.UserData.toString()])
  // ];




  // /* tslint:disable:max-line-length */
  // public mainChartLabels: any = this.datearr;

  // // public mainChartLabels: Array<any> = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Thursday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  // /* tslint:enable:max-line-length */
  // public mainChartOptions: any = {
  //   tooltips: {
  //     enabled: false,
  //     custom: CustomTooltips,
  //     intersect: true,
  //     mode: 'index',
  //     position: 'nearest',
  //     callbacks: {
  //       labelColor: function (tooltipItem, chart) {
  //         return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
  //       }
  //     }
  //   },
  //   responsive: true,
  //   maintainAspectRatio: false,
  //   scales: {
  //     xAxes: [{
  //       gridLines: {
  //         drawOnChartArea: false,
  //       },
  //       ticks: {
  //         callback: function (value: any) {
  //           return value;
  //         }
  //       }
  //     }],
  //     yAxes: [{
  //       ticks: {
  //         beginAtZero: true,
  //         maxTicksLimit: 15,
  //         stepSize: Math.ceil(10 / 10),
  //         max: 10
  //       }
  //     }]
  //   },
  //   elements: {
  //     line: {
  //       borderWidth: 2
  //     },
  //     point: {
  //       radius: 0,
  //       hitRadius: 10,
  //       hoverRadius: 4,
  //       hoverBorderWidth: 3,
  //     }
  //   },
  //   legend: {
  //     display: false
  //   }
  // };
  // public mainChartColours: Array<any> = [
  //   { // brandInfo
  //     backgroundColor: hexToRgba(getStyle('--info'), 10),
  //     borderColor: getStyle('--info'),
  //     pointHoverBackgroundColor: '#fff'
  //   },
  //   { // brandSuccess
  //     backgroundColor: 'transparent',
  //     borderColor: getStyle('--success'),
  //     pointHoverBackgroundColor: '#fff'
  //   },
  //   { // brandDanger
  //     backgroundColor: 'transparent',
  //     borderColor: getStyle('--danger'),
  //     pointHoverBackgroundColor: '#fff',
  //     borderWidth: 1,
  //     borderDash: [8, 5]
  //   }
  // ];
  // public mainChartLegend = false;
  // public mainChartType = 'line';

  // // social box charts

  // public brandBoxChartData1: Array<any> = [
  //   {
  //     data: [65, 59, 84, 84, 51, 55, 40],
  //     label: 'Facebook'
  //   }
  // ];
  // public brandBoxChartData2: Array<any> = [
  //   {
  //     data: [1, 13, 9, 17, 34, 41, 38],
  //     label: 'Twitter'
  //   }
  // ];
  // public brandBoxChartData3: Array<any> = [
  //   {
  //     data: [78, 81, 80, 45, 34, 12, 40],
  //     label: 'LinkedIn'
  //   }
  // ];
  // public brandBoxChartData4: Array<any> = [
  //   {
  //     data: [35, 23, 56, 22, 97, 23, 64],
  //     label: 'Google+'
  //   }
  // ];

  // public brandBoxChartLabels: Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  // public brandBoxChartOptions: any = {
  //   tooltips: {
  //     enabled: false,
  //     custom: CustomTooltips
  //   },
  //   responsive: true,
  //   maintainAspectRatio: false,
  //   scales: {
  //     xAxes: [{
  //       display: false,
  //     }],
  //     yAxes: [{
  //       display: false,
  //     }]
  //   },
  //   elements: {
  //     line: {
  //       borderWidth: 2
  //     },
  //     point: {
  //       radius: 0,
  //       hitRadius: 10,
  //       hoverRadius: 4,
  //       hoverBorderWidth: 3,
  //     }
  //   },
  //   legend: {
  //     display: false
  //   }
  // };
  // public brandBoxChartColours: Array<any> = [
  //   {
  //     backgroundColor: 'rgba(255,255,255,.1)',
  //     borderColor: 'rgba(255,255,255,.55)',
  //     pointHoverBackgroundColor: '#fff'
  //   }
  // ];
  // public brandBoxChartLegend = false;
  // public brandBoxChartType = 'line';

  // public random(min: number, max: number) {
  //   return Math.floor(Math.random() * (max - min + 1) + min);
  // }
  // role;
  // graphData = [];

  // // getGraph() {
  // //   var data =
  // //   {
  // //     "array": [{ "startdate": "2019/07/21", "enddate": "2019/07/22" }, { "startdate": "2019/07/22", "enddate": "2019/07/23" }, { "startdate": "2019/07/23", "enddate": "2019/07/24" }, { "startdate": "2019/07/24", "enddate": "2019/07/25" }, { "startdate": "2019/07/25", "enddate": "2019/07/26" }, { "startdate": "2019/07/26", "enddate": "2019/07/27" }, { "startdate": "2019/07/27", "enddate": "2019/07/28" }],



  // //     "type": 0
  // //   }

  // //   this.appService.getGraph(data).subscribe((res: any) => {
  // //     this.graphData = res;
  // //     this.user_orders = res.user_orders;
  // //     // console.log(this.user_orders);
  // //     // debugger;
  // //     this.vendor_orders = res.vendor_orders;
  // //     alert(this.vendor_orders)
  // //     // this.userCount = res.json().data.users;
  // //   })
  // // }

  // // }
  // Count;
  // userCount;
  // //   userorders: 16
  // // users: 61
  // // venderorders: 12
  // // venders: 0
  // // wholeseller: 11/
  // getAdminCount() {
  //   this.appService.getAdminCount().subscribe((resp: any) => {
  //     this.Count = resp.data;
  //     // this.userCount = res.json().data.users;
  //   })
  // }
  // getWholeProddsCunt() {
  //   this.appService.getWholeProddsCunt().subscribe((res: any) => {
  //     this.wholeCount = res;
  //     // this.userCount = res.json().data.users;
  //   })
  // }
  // getvendorCount() {
  //   this.appService.getvendorCount().subscribe((res: any) => {
  //     this.venCount = res;
  //     // this.userCount = res.json().data.users;
  //   })
  // }
  // test() {

  //   // this.ngOnInit();
  //   // this.router.navigate(['/test']);
  //   // setTimeout(()=>{
  //   //   this.router.navigate(['/dashboard']);
  //   //   // return;
  //   // },2000)
  // }
  // // getWholeProddsCunt(){
  // //     this.appService.getWholeProddsCunt().subscribe(res => {
  // //         this.wholeCount = res.json().data;
  // //         // this.userCount = res.json().data.users;
  // //     })  
  // // }


  // beforeOneMonth: any = '';
  // brforeTwoMonth: any = '';
  // beforeThreeMonth: any = '';
  // beforeFourMonth: any = '';
  // beforeFiveMonth: any = '';
  // beforeSixMonth: any = '';


  // beforeSevenMonth: any = '';
  // brforeEightMonth: any = '';
  // beforeNineMonth: any = '';
  // beforeTenMonth: any = '';
  // before11Month: any = '';
  // before12Month: any = '';


  // // AfterOneMonth: any = '';
  // // AfterTwoMonth: any = '';
  // // AfterThreeMonth: any = '';
  // // AfterFourMonth: any = '';
  // // AfterFiveMonth: any = '';
  // // AfterSixMonth: any = '';

  // ThisMonth: any = '';

  // testMonth: any = '';

  // testMonths() {

  //   var dt1 = new Date();
  //   var dt2 = new Date();
  //   var dt3 = new Date();
  //   var dt4 = new Date();
  //   var dt5 = new Date();
  //   var dt6 = new Date();
  //   var dt7 = new Date();
  //   var dt8 = new Date();
  //   var dt9 = new Date();
  //   var dt10 = new Date();
  //   var dt11 = new Date();
  //   var dt12 = new Date();

  //   var dt13 = new Date();


  //   var d14 = new Date();

  //   this.ThisMonth = dt13.setMonth(dt13.getMonth());

  //   this.testMonth = d14.setMonth(d14.getMonth() - 7);

  //   this.beforeOneMonth = dt1.setMonth(dt1.getMonth() - 1);
  //   this.brforeTwoMonth = dt2.setMonth(dt2.getMonth() - 2);
  //   this.beforeThreeMonth = dt3.setMonth(dt3.getMonth() - 3);
  //   this.beforeFourMonth = dt4.setMonth(dt4.getMonth() - 4);
  //   this.beforeFiveMonth = dt5.setMonth(dt5.getMonth() - 5);
  //   this.beforeSixMonth = dt6.setMonth(dt6.getMonth() - 6);


  //   this.beforeSevenMonth = dt7.setMonth(dt7.getMonth() - 7);
  //   this.brforeEightMonth = dt8.setMonth(dt8.getMonth() - 8);
  //   this.beforeNineMonth = dt9.setMonth(dt9.getMonth() - 9);
  //   this.beforeTenMonth = dt10.setMonth(dt10.getMonth() - 10);
  //   this.before11Month = dt11.setMonth(dt11.getMonth() - 11);
  //   this.before12Month = dt12.setMonth(dt12.getMonth() - 12);



  //   // this.AfterOneMonth = dt7.setMonth(dt7.getMonth() + 1);
  //   // this.AfterTwoMonth = dt8.setMonth(dt8.getMonth() + 2);
  //   // this.AfterThreeMonth = dt9.setMonth(dt9.getMonth() + 3);
  //   // this.AfterFourMonth = dt10.setMonth(dt10.getMonth() + 4);
  //   // this.AfterFiveMonth = dt11.setMonth(dt11.getMonth() + 5);
  //   // this.AfterSixMonth = dt12.setMonth(dt12.getMonth() + 6);


  //   // var OneMonth = new Date(this.beforeOneMonth);
  //   // var TwoMonth = new Date(this.brforeTwoMonth);

  //   // console.log(new Date(this.testMonth));


  //   // console.log(this.datePipe.transform(new Date(this.testMonth), "yyyy/MM/dd"))

  //   // console.log(l + ' ' + m);

  //   var thismonth = this.datePipe.transform(new Date(this.ThisMonth), "yyyy/MM/dd");

  //   var beforeOneMonth1 = this.datePipe.transform(new Date(this.beforeOneMonth), "yyyy/MM/dd");
  //   var brforeTwoMonth1 = this.datePipe.transform(new Date(this.brforeTwoMonth), "yyyy/MM/dd");
  //   var beforeThreeMonth1 = this.datePipe.transform(new Date(this.beforeThreeMonth), "yyyy/MM/dd");
  //   var beforeFourMonth1 = this.datePipe.transform(new Date(this.beforeFourMonth), "yyyy/MM/dd");
  //   var beforeFiveMonth1 = this.datePipe.transform(new Date(this.beforeFiveMonth), "yyyy/MM/dd");
  //   var beforeSixMonth1 = this.datePipe.transform(new Date(this.beforeSixMonth), "yyyy/MM/dd");


  //   var beforeSevenMonth1 = this.datePipe.transform(new Date(this.beforeSevenMonth), "yyyy/MM/dd");
  //   var brforeEightMonth1 = this.datePipe.transform(new Date(this.brforeEightMonth), "yyyy/MM/dd");
  //   var beforeNineMonth1 = this.datePipe.transform(new Date(this.beforeNineMonth), "yyyy/MM/dd");
  //   var beforeTenMonth1 = this.datePipe.transform(new Date(this.beforeTenMonth), "yyyy/MM/dd");
  //   var before11Month1 = this.datePipe.transform(new Date(this.before11Month), "yyyy/MM/dd");
  //   var before12Month1 = this.datePipe.transform(new Date(this.before12Month), "yyyy/MM/dd");



  //   // var AfterOneMonth1 = this.datePipe.transform(new Date(this.AfterOneMonth), "yyyy/MM/dd");
  //   // var AfterTwoMonth1 = this.datePipe.transform(new Date(this.AfterTwoMonth), "yyyy/MM/dd");
  //   // var AfterThreeMonth1 = this.datePipe.transform(new Date(this.AfterThreeMonth), "yyyy/MM/dd");
  //   // var AfterFourMonth1 = this.datePipe.transform(new Date(this.AfterFourMonth), "yyyy/MM/dd");
  //   // var AfterFiveMonth1 = this.datePipe.transform(new Date(this.AfterFiveMonth), "yyyy/MM/dd");
  //   // var AfterSixMonth1 = this.datePipe.transform(new Date(this.AfterSixMonth), "yyyy/MM/dd");


  //   // console.log(thismonth);
  //   // console.log(beforeOneMonth1 + ' ' + brforeTwoMonth1 + ' ' + beforeThreeMonth1 + ' '
  //   // + beforeFourMonth1 + ' ' + beforeFiveMonth1 + ' ' + beforeSixMonth1);


  //   var date = new Date(thismonth);
  //   var firstDayofthisMonth = new Date(date.getFullYear(), date.getMonth(), 1);
  //   var lastDayofthisMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0);

  //   var firstDayofthisMonthFormat = this.datePipe.transform(new Date(firstDayofthisMonth), "yyyy/MM/dd");
  //   var lastDayofthisMonthFormat = this.datePipe.transform(new Date(lastDayofthisMonth), "yyyy/MM/dd");


  //   var date1 = new Date(beforeOneMonth1);
  //   var firstDayofbeforeOneMonth = new Date(date1.getFullYear(), date1.getMonth(), 1);
  //   var lastDaybeforeOneMonth = new Date(date1.getFullYear(), date1.getMonth() + 1, 0);


  //   var firstDayofbeforeOneMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeOneMonth), "yyyy/MM/dd");
  //   var lastDaybeforeOneMonthFormat = this.datePipe.transform(new Date(lastDaybeforeOneMonth), "yyyy/MM/dd");

  //   var date2 = new Date(brforeTwoMonth1);

  //   var firstDayofbeforeTwoMonth = new Date(date2.getFullYear(), date2.getMonth(), 1);
  //   var lastDaybeforeTwoMonth = new Date(date2.getFullYear(), date2.getMonth() + 1, 0);

  //   var firstDayofbeforeTwoMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeTwoMonth), "yyyy/MM/dd");
  //   var lastDaybeforeTwoMonthFormat = this.datePipe.transform(new Date(lastDaybeforeTwoMonth), "yyyy/MM/dd");



  //   var date3 = new Date(beforeThreeMonth1);

  //   var firstDayofbeforeThreeMonth = new Date(date3.getFullYear(), date3.getMonth(), 1);
  //   var lastDaybeforeThreeMonth = new Date(date3.getFullYear(), date3.getMonth() + 1, 0);

  //   var firstDayofbeforeThreeMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeThreeMonth), "yyyy/MM/dd");
  //   var lastDaybeforeThreeMonthFormat = this.datePipe.transform(new Date(lastDaybeforeThreeMonth), "yyyy/MM/dd");



  //   var date4 = new Date(beforeFourMonth1);

  //   var firstDayofbeforeFourMonth = new Date(date4.getFullYear(), date4.getMonth(), 1);
  //   var lastDaybeforeFourMonth = new Date(date4.getFullYear(), date4.getMonth() + 1, 0);


  //   var firstDayofbeforeFourMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeFourMonth), "yyyy/MM/dd");
  //   var lastDaybeforeFourMonthFormat = this.datePipe.transform(new Date(lastDaybeforeFourMonth), "yyyy/MM/dd");




  //   var date5 = new Date(beforeFiveMonth1);

  //   var firstDayofbeforeFiveMonth = new Date(date5.getFullYear(), date5.getMonth(), 1);
  //   var lastDaybeforeFiveMonth = new Date(date5.getFullYear(), date5.getMonth() + 1, 0);

  //   var firstDayofbeforeFiveMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeFiveMonth), "yyyy/MM/dd");
  //   var lastDaybeforeFiveMonthFormat = this.datePipe.transform(new Date(lastDaybeforeFiveMonth), "yyyy/MM/dd");






  //   var date6 = new Date(beforeSixMonth1);

  //   var firstDayofbeforeSixMonth = new Date(date6.getFullYear(), date6.getMonth(), 1);
  //   var lastDaybeforeSixMonth = new Date(date6.getFullYear(), date6.getMonth() + 1, 0);


  //   var firstDayofbeforeSixMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeSixMonth), "yyyy/MM/dd");
  //   var lastDaybeforeSixMonthFormat = this.datePipe.transform(new Date(lastDaybeforeSixMonth), "yyyy/MM/dd");






  //   var date7 = new Date(beforeSevenMonth1);

  //   var firstDayofbeforeSevenMonth = new Date(date7.getFullYear(), date7.getMonth(), 1);
  //   var lastDaybeforeSevenMonth = new Date(date7.getFullYear(), date7.getMonth() + 1, 0);

  //   var firstDayofbeforeSevenMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeSevenMonth), "yyyy/MM/dd");
  //   var lastDaybeforeSevenMonthFormat = this.datePipe.transform(new Date(lastDaybeforeSevenMonth), "yyyy/MM/dd");



  //   var date8 = new Date(brforeEightMonth1);

  //   var firstDayofbeforeEightMonth = new Date(date8.getFullYear(), date8.getMonth(), 1);
  //   var lastDaybeforeEightMonth = new Date(date8.getFullYear(), date8.getMonth() + 1, 0);


  //   var firstDayofbeforeEightMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeEightMonth), "yyyy/MM/dd");
  //   var lastDaybeforeEightMonthFormat = this.datePipe.transform(new Date(lastDaybeforeEightMonth), "yyyy/MM/dd");


  //   var date9 = new Date(beforeNineMonth1);

  //   var firstDayofbeforeNineMonth = new Date(date9.getFullYear(), date9.getMonth(), 1);
  //   var lastDaybeforeNineMonth = new Date(date9.getFullYear(), date9.getMonth() + 1, 0);

  //   var firstDayofbeforeNineMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeNineMonth), "yyyy/MM/dd");
  //   var lastDaybeforeNineMonthFormat = this.datePipe.transform(new Date(lastDaybeforeNineMonth), "yyyy/MM/dd");


  //   var date10 = new Date(beforeTenMonth1);

  //   var firstDayofbeforeTenMonth = new Date(date10.getFullYear(), date10.getMonth(), 1);
  //   var lastDaybeforeTenMonth = new Date(date10.getFullYear(), date10.getMonth() + 1, 0);

  //   var firstDayofbeforeTenMonthFormat = this.datePipe.transform(new Date(firstDayofbeforeTenMonth), "yyyy/MM/dd");
  //   var lastDaybeforeTenMonthFormat = this.datePipe.transform(new Date(lastDaybeforeTenMonth), "yyyy/MM/dd");


  //   var date11 = new Date(before11Month1);

  //   var firstDayofbefore11Month = new Date(date11.getFullYear(), date11.getMonth(), 1);
  //   var lastDaybefore11Month = new Date(date11.getFullYear(), date11.getMonth() + 1, 0);



  //   var firstDayofbefore11MonthFormat = this.datePipe.transform(new Date(firstDayofbefore11Month), "yyyy/MM/dd");
  //   var lastDaybefore11MonthFormat = this.datePipe.transform(new Date(lastDaybefore11Month), "yyyy/MM/dd");



  //   var date12 = new Date(before12Month1);

  //   var firstDayofbefore12Month = new Date(date12.getFullYear(), date12.getMonth(), 1);
  //   var lastDaybefore12Month = new Date(date12.getFullYear(), date12.getMonth() + 1, 0);

  //   var firstDayofbefore12MonthFormat = this.datePipe.transform(new Date(firstDayofbefore12Month), "yyyy/MM/dd");
  //   var lastDaybefore12MonthFormat = this.datePipe.transform(new Date(lastDaybefore12Month), "yyyy/MM/dd");



  //   var MonthObj = {
  //     "array": [{ "startdate": firstDayofthisMonthFormat, "enddate": lastDayofthisMonthFormat },
  //     { "startdate": firstDayofbeforeOneMonthFormat, "enddate": lastDaybeforeOneMonthFormat },
  //     { "startdate": firstDayofbeforeTwoMonthFormat, "enddate": lastDaybeforeTwoMonthFormat },
  //     { "startdate": firstDayofbeforeThreeMonthFormat, "enddate": lastDaybeforeThreeMonthFormat },
  //     { "startdate": firstDayofbeforeFourMonthFormat, "enddate": lastDaybeforeFourMonthFormat },
  //     { "startdate": firstDayofbeforeFiveMonthFormat, "enddate": lastDaybeforeFiveMonthFormat },
  //     { "startdate": firstDayofbeforeSixMonthFormat, "enddate": lastDaybeforeSixMonthFormat },
  //     { "startdate": firstDayofbeforeSevenMonthFormat, "enddate": lastDaybeforeSevenMonthFormat },
  //     { "startdate": firstDayofbeforeEightMonthFormat, "enddate": lastDaybeforeEightMonthFormat },
  //     { "startdate": firstDayofbeforeNineMonthFormat, "enddate": lastDaybeforeNineMonthFormat },
  //     { "startdate": firstDayofbeforeTenMonthFormat, "enddate": lastDaybeforeTenMonthFormat },
  //     { "startdate": firstDayofbefore11MonthFormat, "enddate": lastDaybefore11MonthFormat },
  //     { "startdate": firstDayofbefore12MonthFormat, "enddate": lastDaybefore12MonthFormat },
  //     ],
  //     "type": 0
  //   }
  //   this.appService.getGraph(MonthObj).subscribe((res: any) => {
  //     this.graphData = res;
  //     this.user_orders = res.user_orders;
  //     this.UserOrder = this.user_orders;
  //     localStorage.setItem("user_orders", JSON.stringify(res.user_orders));
  //     this.vendor_orders = res.vendor_orders;
  //   });

  //   console.log(MonthObj);
  // }



  // listDate = [];

  // getOneMonthDays() {
  //   var currdate = new Date(); // get current date
  //   // var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
  //   var CurrentMonthStartDate = new Date(currdate.getFullYear(), currdate.getMonth(), 1);
  //   var CurrentMonthLastDate = new Date(currdate.getFullYear(), currdate.getMonth() + 1, 0);
  //   var CurrentMonthLastDate1 = new Date(currdate.getFullYear(), currdate.getMonth(), 2);
  //   console.log(CurrentMonthLastDate);
  //   var lastday = CurrentMonthLastDate.getDate();
  //   console.log(lastday);
  //   for (var i = 1; i <= lastday; i++) {
  //     // this.listDate.push({ startdate : new Date(currdate.getFullYear(), currdate.getMonth(), i) ,
  //     // enddate : new Date(currdate.getFullYear(), currdate.getMonth(), i + 1 ) } );
  //     this.listDate.push({
  //       startdate: (this.datePipe.transform(new Date(currdate.getFullYear(), currdate.getMonth(), i), "yyyy/MM/dd")),
  //       enddate: (this.datePipe.transform(new Date(currdate.getFullYear(), currdate.getMonth(), i + 1), "yyyy/MM/dd"))
  //     });
  //     // console.log(i);
  //   }
  //   this.appService.getGraph(this.listDate).subscribe((res: any) => {
  //     this.graphData = res;
  //     this.user_orders = res.user_orders;
  //     this.UserOrder = this.user_orders;
  //     localStorage.setItem("user_orders", JSON.stringify(res.user_orders));
  //     this.vendor_orders = res.vendor_orders;
  //   });
  //   console.log(this.listDate);
  //   // console.log(CurrentMonthLastDate1);
  //   // console.log(CurrentMonthStartDate);
  //   // console.log(CurrentMonthLastDate);
  // }


}
