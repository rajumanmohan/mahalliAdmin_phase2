import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { AppService } from './../../services/mahali/mahali-data.service';
import { navItems } from '../../_nav';

import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';

import { DatePipe } from '@angular/common';


@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent implements OnInit {





    constructor(private appService: AppService, public router: Router, private datePipe: DatePipe) {
  this.test();
  this.router.navigate(['/dashboard']);
}
  public navItems = navItems;


radioModel: string = 'Month';
wholeCount = [];
venCount: [];
user_orders = [];
vendor_orders = [];
showDayGraph = true;
showMonthGraph = false;
showYearGraph = false;

ChartArrOne = [];


WeekChart_user_orders = [];

WeekChart_vendor_orders = [];


dayGraph() {
  this.showDayGraph = true;
  this.showMonthGraph = false;
  this.showYearGraph = false;
}
monthGraph() {
  this.showDayGraph = false;
  this.showMonthGraph = true;
  this.showYearGraph = false;
}
yearGraph() {
  this.showDayGraph = false;
  this.showMonthGraph = false;
  this.showYearGraph = true;
}
wholeshowDayGraph = true;
wholeshowMonthGraph = false;
wholeshowYearGraph = false;
wholedayGraph() {
  this.wholeshowDayGraph = true;
  this.wholeshowMonthGraph = false;
  this.wholeshowYearGraph = false;
}
wholemonthGraph() {
  this.wholeshowDayGraph = false;
  this.wholeshowMonthGraph = true;
  this.wholeshowYearGraph = false;
}
wholeyearGraph() {
  this.wholeshowDayGraph = false;
  this.wholeshowMonthGraph = false;
  this.wholeshowYearGraph = true;
}
vendorshowDayGraph = true;
vendorshowMonthGraph = false;
vendorshowYearGraph = false;
vendordayGraph() {
  this.vendorshowDayGraph = true;
  this.vendorshowMonthGraph = false;
  this.vendorshowYearGraph = false;
}
vendormonthGraph() {
  this.vendorshowDayGraph = false;
  this.vendorshowMonthGraph = true;
  this.vendorshowYearGraph = false;
}
vendoryearGraph() {
  this.vendorshowDayGraph = false;
  this.vendorshowMonthGraph = false;
  this.vendorshowYearGraph = true;
}
  // lineChart1
  public lineChart1Data: Array < any > =[
  {
    data: [65, 59, 84, 84, 51, 55, 40],
    label: 'Series A'
  }
];
  public lineChart1Labels: Array < any > =['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChart1Options: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips
  },
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        color: 'transparent',
        zeroLineColor: 'transparent'
      },
      ticks: {
        fontSize: 2,
        fontColor: 'transparent',
      }

    }],
    yAxes: [{
      display: false,
      ticks: {
        display: false,
        min: 40 - 5,
        max: 84 + 5,
      }
    }],
  },
  elements: {
    line: {
      borderWidth: 1
    },
    point: {
      radius: 4,
      hitRadius: 10,
      hoverRadius: 4,
    },
  },
  legend: {
    display: false
  }
};
  public lineChart1Colours: Array < any > =[
  {
    backgroundColor: getStyle('--primary'),
    borderColor: 'rgba(255,255,255,.55)'
  }
];
  public lineChart1Legend = false;
  public lineChart1Type = 'line';

  // lineChart2
  public lineChart2Data: Array < any > =[
  {
    data: [1, 18, 9, 17, 34, 22, 11],
    label: 'Series A'
  }
];
  public lineChart2Labels: Array < any > =['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChart2Options: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips
  },
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        color: 'transparent',
        zeroLineColor: 'transparent'
      },
      ticks: {
        fontSize: 2,
        fontColor: 'transparent',
      }

    }],
    yAxes: [{
      display: false,
      ticks: {
        display: false,
        min: 1 - 5,
        max: 34 + 5,
      }
    }],
  },
  elements: {
    line: {
      tension: 0.00001,
      borderWidth: 1
    },
    point: {
      radius: 4,
      hitRadius: 10,
      hoverRadius: 4,
    },
  },
  legend: {
    display: false
  }
};
  public lineChart2Colours: Array < any > =[
  { // grey
    backgroundColor: getStyle('--info'),
    borderColor: 'rgba(255,255,255,.55)'
  }
];
  public lineChart2Legend = false;
  public lineChart2Type = 'line';


  // lineChart3
  public lineChart3Data: Array < any > =[
  {
    data: [78, 81, 80, 45, 34, 12, 40],
    label: 'Series A'
  }
];
  public lineChart3Labels: Array < any > =['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChart3Options: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips
  },
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      display: false
    }],
    yAxes: [{
      display: false
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
    },
  },
  legend: {
    display: false
  }
};
  public lineChart3Colours: Array < any > =[
  {
    backgroundColor: 'rgba(255,255,255,.2)',
    borderColor: 'rgba(255,255,255,.55)',
  }
];
  public lineChart3Legend = false;
  public lineChart3Type = 'line';


  // barChart1
  public barChart1Data: Array < any > =[
  {
    data: [78, 81, 80, 45, 34, 12, 40, 78, 81, 80, 45, 34, 12, 40, 12, 40],
    label: 'Series A'
  }
];
  public barChart1Labels: Array < any > =['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16'];
  public barChart1Options: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips
  },
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      display: false,
      barPercentage: 0.6,
    }],
    yAxes: [{
      display: false
    }]
  },
  legend: {
    display: false
  }
};
  public barChart1Colours: Array < any > =[
  {
    backgroundColor: 'rgba(255,255,255,.3)',
    borderWidth: 0
  }
];
  public barChart1Legend = false;
  public barChart1Type = 'bar';

  // mainChart

  public mainChartElements = 27;

  public mainChartData1: Array < number > =[

];
  public mainChartData2: Array < number > =[

];
  public mainChartDataYear: Array < any > =[

  {
    data: [90, 180, 200, 231, 147, 247, 136, 157, 324, 259, 201, 321],
    label: 'User Orders'
  },
  {
    data: [110, 160, 140, 131, 241, 277, 136, 217, 264, 157, 361, 211],
    label: 'Vendor Orders'
  },
];



  // public mainChartData3: Array<number> = [];
  public mainChartDataMonth: Array < any > =[
  {
    data: [100, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 45],
    label: 'User Orders'

  },
  {
    data: [8, 4, 23, 5, 69, 51, 4, 2, 5, 4, 6, 8, 4, 1, 2, 6, 4, 7, 2, 6, 9, 4, 1, 8, 50, 1, 3, 0, 10, 0, 4],
    label: 'Vendor Orders'
  },

];
  public mainChartData: Array < any > =[
  {
    data: [0, 1, 2, 0, 0, 0, 0],
    label: 'User Orders'
  },
  {
    data: [0, 1, 3, 0, 0, 0, 0],
    label: 'Vendor Orders'
  },
  // {
  //   data: this.mainChartData3,
  //   label: 'BEP'
  // }
];
  /* tslint:disable:max-line-length */

  public mainChartLabelsYear: Array < any > =['August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June', 'July'];

  public mainChartLabels: Array < any > =['21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019'];
  // public mainChartLabels: Array<any> = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Thursday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  /* tslint:enable:max-line-length */
  public mainChartLabelsMonth: Array < any > =['01/07/2019', '02/07/2019', '03/07/2019', '04/07/2019', '05/07/2019', '06/07/2019', '07/07/2019', '08/07/2019', '09/07/2019', '10/07/2019', '11/07/2019', '12/07/2019', '13/07/2019', '14/07/2019', '15/07/2019', '16/07/2019', '17/07/2019', '18/07/2019', '19/07/2019', '20/07/2019', '21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019', '28/07/2019', '29/07/2019', '30/07/2019', '31/07/2019'];
  public mainChartOptions: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(10 / 10),
        max: 10
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public mainChartOptionsmonth: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(100 / 100),
        max: 100
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public mainChartOptionsYear: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(600 / 600),
        max: 600
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public mainChartColours: Array < any > =[
  { // brandInfo
    backgroundColor: hexToRgba(getStyle('--info'), 10),
    borderColor: getStyle('--info'),
    pointHoverBackgroundColor: '#fff'
  },
  { // brandSuccess
    backgroundColor: 'transparent',
    borderColor: getStyle('--success'),
    pointHoverBackgroundColor: '#fff'
  },
  { // brandDanger
    backgroundColor: 'transparent',
    borderColor: getStyle('--danger'),
    pointHoverBackgroundColor: '#fff',
    borderWidth: 1,
    borderDash: [8, 5]
  }
];
  public mainChartLegend = false;
  public mainChartType = 'line';

  // social box charts

  public brandBoxChartData1: Array < any > =[
  {
    data: [65, 59, 84, 84, 51, 55, 40],
    label: 'Facebook'
  }
];
  public brandBoxChartData2: Array < any > =[
  {
    data: [1, 13, 9, 17, 34, 41, 38],
    label: 'Twitter'
  }
];
  public brandBoxChartData3: Array < any > =[
  {
    data: [78, 81, 80, 45, 34, 12, 40],
    label: 'LinkedIn'
  }
];
  public brandBoxChartData4: Array < any > =[
  {
    data: [35, 23, 56, 22, 97, 23, 64],
    label: 'Google+'
  }
];















  public brandBoxChartLabels: Array < any > =['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public brandBoxChartOptions: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      display: false,
    }],
    yAxes: [{
      display: false,
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public brandBoxChartColours: Array < any > =[
  {
    backgroundColor: 'rgba(255,255,255,.1)',
    borderColor: 'rgba(255,255,255,.55)',
    pointHoverBackgroundColor: '#fff'
  }
];
  public brandBoxChartLegend = false;
  public brandBoxChartType = 'line';

  public random(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1) + min);
}
role;
graphData = [];
ngOnInit(): void {
  this.testmethod();
  this.getWeekChartsMethod();
  this.getWeekChartsMethod();
  // this.reload();
  // this.getGraph();
  this.role = sessionStorage.role;
  this.getAdminCount();
  // generate random values for mainChart
  for(let i = 0; i <= this.mainChartElements; i++) {
  this.mainChartData1.push(this.random(50, 200));
  this.mainChartData2.push(this.random(80, 100));
  // this.mainChartData3.push(65);
  if (sessionStorage.role == 'wholesaler') {
    this.getWholeProddsCunt();
  } else {
    this.getvendorCount();
  }
}
  }
getGraph() {
  var data =
  {
    "array": [{ "startdate": "2019/07/21", "enddate": "2019/07/22" }, { "startdate": "2019/07/22", "enddate": "2019/07/23" }, { "startdate": "2019/07/23", "enddate": "2019/07/24" }, { "startdate": "2019/07/24", "enddate": "2019/07/25" }, { "startdate": "2019/07/25", "enddate": "2019/07/26" }, { "startdate": "2019/07/26", "enddate": "2019/07/27" }, { "startdate": "2019/07/27", "enddate": "2019/07/28" }],



    "type": 0
  }

  this.appService.getGraph(data).subscribe((res: any) => {
    this.graphData = res;

    this.ChartArrOne = res;
    this.user_orders = res.user_orders;
    // console.log(this.user_orders);
    // debugger;
    this.vendor_orders = res.vendor_orders;
    // this.userCount = res.json().data.users;
  })
}

// }
Count;
userCount;
//   userorders: 16
// users: 61
// venderorders: 12
// venders: 0
// wholeseller: 11/
getAdminCount() {
  this.appService.getAdminCount().subscribe((resp: any) => {
    this.Count = resp.data;
    // this.userCount = res.json().data.users;
  })
}
getWholeProddsCunt() {
  this.appService.getWholeProddsCunt().subscribe((res: any) => {
    this.wholeCount = res;
    // this.userCount = res.json().data.users;
  })
}
getvendorCount() {
  this.appService.getvendorCount().subscribe((res: any) => {
    this.venCount = res;
    // this.userCount = res.json().data.users;
  })
}
test() {

  // this.ngOnInit();
  // this.router.navigate(['/test']);
  // setTimeout(()=>{
  //   this.router.navigate(['/dashboard']);
  //   // return;
  // },2000)
}
// getWholeProddsCunt(){
//     this.appService.getWholeProddsCunt().subscribe(res => {
//         this.wholeCount = res.json().data;
//         // this.userCount = res.json().data.users;
//     })  
// }


firstday = '';
secondday = '';
thirdday = '';
fourthday = '';
fifthday = '';
sixthday = '';

lastday = '';

verylastday = '';

getWeekChartsMethod() {




  var curr = new Date; // get current date
  var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week

  var varylast1 = first + 7; // last day is the first day + 6


  var last = first + 6; // last day is the first day + 6
  var lasttosecond = first + 5; // last day is the first day + 6
  var lasttothird = first + 4; // last day is the first day + 6

  var lasttofouth = first + 3; // last day is the first day + 6

  var lasttofifth = first + 2; // last day is the first day + 6

  var lasttosixth = first + 1; // last day is the first day + 6


  this.firstday = new Date(curr.setDate(first)).toUTCString();
  this.secondday = new Date(curr.setDate(lasttosixth)).toUTCString();
  this.thirdday = new Date(curr.setDate(lasttofifth)).toUTCString();
  this.fourthday = new Date(curr.setDate(lasttofouth)).toUTCString();
  this.fifthday = new Date(curr.setDate(lasttothird)).toUTCString();
  this.sixthday = new Date(curr.setDate(lasttosecond)).toUTCString();


  this.lastday = new Date(curr.setDate(last)).toUTCString();

  this.verylastday = new Date(curr.setDate(varylast1)).toUTCString();




  var firstdayOne = this.datePipe.transform(this.firstday, "yyyy/MM/dd");
  var seconddayOne = this.datePipe.transform(this.secondday, "yyyy/MM/dd");

  var thirddayOne = this.datePipe.transform(this.thirdday, "yyyy/MM/dd");

  var fourthdayOne = this.datePipe.transform(this.fourthday, "yyyy/MM/dd");

  var fifthdayOne = this.datePipe.transform(this.fifthday, "yyyy/MM/dd");

  var sixthdayOne = this.datePipe.transform(this.sixthday, "yyyy/MM/dd");

  var lastdayOne = this.datePipe.transform(this.lastday, "yyyy/MM/dd");

  var verylastdayOne = this.datePipe.transform(this.verylastday, "yyyy/MM/dd");



  var arr = {
    "array": [{ "startdate": firstdayOne, "enddate": seconddayOne },
    { "startdate": seconddayOne, "enddate": thirddayOne },
    { "startdate": thirddayOne, "enddate": fourthdayOne },
    { "startdate": fourthdayOne, "enddate": fifthdayOne },
    { "startdate": fifthdayOne, "enddate": sixthdayOne },
    { "startdate": sixthdayOne, "enddate": lastdayOne },
    { "startdate": lastdayOne, "enddate": verylastdayOne }],

    "type": 0
  }
  var datearr = []
  arr.array.forEach(element => {
    datearr.push(element.startdate)
    if (arr.array.length == datearr.length) {
      console.log(datearr, ">>>>>>>>>>>>")
    }
  });

  this.appService.getGraph(arr).subscribe((res: any) => {
    this.graphData = res;

    // this.user_orders = res.user_orders;

    this.user_orders = res['user_orders'].map(res => res);



    this.WeekChart_user_orders = '';

    this.WeekChart_vendor_orders = '';

    localStorage.setItem('WeekChart_user_orders', JSON.stringify(this.WeekChart_user_orders));

    localStorage.setItem('WeekChart_vendor_orders', JSON.stringify(this.WeekChart_vendor_orders));


    console.log(JSON.parse(localStorage.getItem('WeekChart_user_orders')));

    console.log(JSON.parse(localStorage.getItem('WeekChart_vendor_orders')));


    // let temp_max = res['user_orders'].map(res => res);

    // alert(temp_max);
    // console.log(this.user_orders);
    // debugger;
    // this.vendor_orders = res.vendor_orders;


    this.vendor_orders = res['vendor_orders'].map(res => res);


    // this.userCount = res.json().data.users;
  })

  console.log(arr);

}

  public wholeSellermainChartDataYear: Array < any > =[

  // {
  //   data: [90, 180, 200, 231, 147, 247, 136, 157, 324, 259, 201, 321],
  //   label: 'User Orders'
  // },
  {
    data: this.vendor_orders,
    label: 'Vendor Orders'
  },
];
  // public mainChartData3: Array<number> = [];
  public wholeSellermainChartDataMonth: Array < any > =[
  // {
  //   data: [0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 45],
  //   label: 'User Orders'
  // },
  {
    data: this.user_orders,
    label: 'Vendor Orders'
  },

];
  public wholeSellermainChartData: Array < any > =[
  // {
  //   data: [0, 1, 2, 0, 0, 0, 0],
  //   label: 'User Orders'
  // },
  {
    data: [0, 1, 3, 0, 0, 0, 0],
    label: 'Vendor Orders'
  },
  // {
  //   data: this.mainChartData3,
  //   label: 'BEP'
  // }
];
  public wholeSellermainChartLabelsYear: Array < any > =['August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June', 'July'];

  public wholeSellermainChartLabels: Array < any > =['21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019'];
  // public mainChartLabels: Array<any> = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Thursday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  /* tslint:enable:max-line-length */
  public wholeSellermainChartLabelsMonth: Array < any > =['01/07/2019', '02/07/2019', '03/07/2019', '04/07/2019', '05/07/2019', '06/07/2019', '07/07/2019', '08/07/2019', '09/07/2019', '10/07/2019', '11/07/2019', '12/07/2019', '13/07/2019', '14/07/2019', '15/07/2019', '16/07/2019', '17/07/2019', '18/07/2019', '19/07/2019', '20/07/2019', '21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019', '28/07/2019', '29/07/2019', '30/07/2019', '31/07/2019'];
  public wholeSellermainChartOptions: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(10 / 10),
        max: 10
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public wholeSellermainChartOptionsmonth: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(100 / 100),
        max: 100
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public wholeSellermainChartOptionsYear: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(600 / 600),
        max: 600
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};







  public vendormainChartDataYear: Array < any > =[

  {
    data: [90, 180, 200, 231, 147, 247, 136, 157, 324, 259, 201, 321],
    label: 'User Orders'
  },
  // {
  //   data: [110, 160, 140, 131, 241, 277, 136, 217, 264, 157, 361, 211],
  //   label: 'Vendor Orders'
  // },
];
  // public mainChartData3: Array<number> = [];
  public vendormainChartDataMonth: Array < any > =[
  {
    // data: [10, 50, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 45],
    data: [100, 50, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 0, 10, 2, 0, 50, 0, 1, 47, 14, 12, 45],
    label: 'User Orders'
  },
  // {
  //   data: [8, 4, 23, 5, 69, 51, 4, 2, 5, 4, 6, 8, 4, 1, 2, 6, 4, 7, 2, 6, 9, 4, 1, 8, 50, 1, 3, 0, 10, 0, 4],
  //   label: 'Vendor Orders'
  // },

];
  public vendormainChartData: Array < any > =[
  {
    data: [10, 1, 2, 0, 0, 0, 0],
    label: 'User Orders'
  },
  // {
  //   data: [0, 1, 3, 0, 0, 0, 0],
  //   label: 'Vendor Orders'
  // },
  // {
  //   data: this.mainChartData3,
  //   label: 'BEP'
  // }
];
  public vendormainChartLabelsYear: Array < any > =['August', 'September', 'October', 'November', 'December', 'January', 'February', 'March', 'April', 'May', 'June', 'July'];

  public vendormainChartLabels: Array < any > =['21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019'];
  // public mainChartLabels: Array<any> = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'Monday', 'Thursday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  /* tslint:enable:max-line-length */
  public vendormainChartLabelsMonth: Array < any > =['01/07/2019', '02/07/2019', '03/07/2019', '04/07/2019', '05/07/2019', '06/07/2019', '07/07/2019', '08/07/2019', '09/07/2019', '10/07/2019', '11/07/2019', '12/07/2019', '13/07/2019', '14/07/2019', '15/07/2019', '16/07/2019', '17/07/2019', '18/07/2019', '19/07/2019', '20/07/2019', '21/07/2019', '22/07/2019', '23/07/2019', '24/07/2019', '25/07/2019', '26/07/2019', '27/07/2019', '28/07/2019', '29/07/2019', '30/07/2019', '31/07/2019'];
  public vendormainChartOptions: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(10 / 10),
        max: 10
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public vendormainChartOptionsmonth: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(100 / 100),
        max: 100
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};
  public vendormainChartOptionsYear: any = {
  tooltips: {
    enabled: false,
    custom: CustomTooltips,
    intersect: true,
    mode: 'index',
    position: 'nearest',
    callbacks: {
      labelColor: function (tooltipItem, chart) {
        return { backgroundColor: chart.data.datasets[tooltipItem.datasetIndex].borderColor };
      }
    }
  },
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    xAxes: [{
      gridLines: {
        drawOnChartArea: false,
      },
      ticks: {
        callback: function (value: any) {
          return value;
        }
      }
    }],
    yAxes: [{
      ticks: {
        beginAtZero: true,
        maxTicksLimit: 15,
        stepSize: Math.ceil(600 / 600),
        max: 600
      }
    }]
  },
  elements: {
    line: {
      borderWidth: 2
    },
    point: {
      radius: 0,
      hitRadius: 10,
      hoverRadius: 4,
      hoverBorderWidth: 3,
    }
  },
  legend: {
    display: false
  }
};




localTestUO = [];

localTestVO = [];



testmethod() {



  var curr = new Date; // get current date
  var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week

  var varylast1 = first + 7; // last day is the first day + 6


  var last = first + 6; // last day is the first day + 6
  var lasttosecond = first + 5; // last day is the first day + 6
  var lasttothird = first + 4; // last day is the first day + 6

  var lasttofouth = first + 3; // last day is the first day + 6

  var lasttofifth = first + 2; // last day is the first day + 6

  var lasttosixth = first + 1; // last day is the first day + 6


  this.firstday = new Date(curr.setDate(first)).toUTCString();
  this.secondday = new Date(curr.setDate(lasttosixth)).toUTCString();
  this.thirdday = new Date(curr.setDate(lasttofifth)).toUTCString();
  this.fourthday = new Date(curr.setDate(lasttofouth)).toUTCString();
  this.fifthday = new Date(curr.setDate(lasttothird)).toUTCString();
  this.sixthday = new Date(curr.setDate(lasttosecond)).toUTCString();


  this.lastday = new Date(curr.setDate(last)).toUTCString();

  this.verylastday = new Date(curr.setDate(varylast1)).toUTCString();




  var firstdayOne = this.datePipe.transform(this.firstday, "yyyy/MM/dd");
  var seconddayOne = this.datePipe.transform(this.secondday, "yyyy/MM/dd");

  var thirddayOne = this.datePipe.transform(this.thirdday, "yyyy/MM/dd");

  var fourthdayOne = this.datePipe.transform(this.fourthday, "yyyy/MM/dd");

  var fifthdayOne = this.datePipe.transform(this.fifthday, "yyyy/MM/dd");

  var sixthdayOne = this.datePipe.transform(this.sixthday, "yyyy/MM/dd");

  var lastdayOne = this.datePipe.transform(this.lastday, "yyyy/MM/dd");

  var verylastdayOne = this.datePipe.transform(this.verylastday, "yyyy/MM/dd");



  var arr = {
    "array": [{ "startdate": firstdayOne, "enddate": seconddayOne },
    { "startdate": seconddayOne, "enddate": thirddayOne },
    { "startdate": thirddayOne, "enddate": fourthdayOne },
    { "startdate": fourthdayOne, "enddate": fifthdayOne },
    { "startdate": fifthdayOne, "enddate": sixthdayOne },
    { "startdate": sixthdayOne, "enddate": lastdayOne },
    { "startdate": lastdayOne, "enddate": verylastdayOne }],

    "type": 0
  }
  var datearr = []
  arr.array.forEach(element => {
    datearr.push(element.startdate)
    if (arr.array.length == datearr.length) {
      console.log(datearr, ">>>>>>>>>>>>")
    }
  });


  console.log(arr);

  this.appService.getGraph(arr).subscribe((res: any) => {

    this.graphData = res;

    // this.user_orders = res.user_orders;

    this.user_orders = res['user_orders'].map(res => res);



    this.WeekChart_user_orders = res.user_orders;

    this.WeekChart_vendor_orders = res.vendor_orders;

    localStorage.setItem('WeekChart_user_orders', JSON.stringify(this.WeekChart_user_orders));

    localStorage.setItem('WeekChart_vendor_orders', JSON.stringify(this.WeekChart_vendor_orders));


    console.log(JSON.parse(localStorage.getItem('WeekChart_user_orders')));

    console.log(JSON.parse(localStorage.getItem('WeekChart_vendor_orders')));


    // let temp_max = res['user_orders'].map(res => res);

    // alert(temp_max);
    // console.log(this.user_orders);
    // debugger;
    // this.vendor_orders = res.vendor_orders;


    this.vendor_orders = res['vendor_orders'].map(res => res);


    // this.userCount = res.json().data.users;
  })

  console.log(arr);

  // var data =
  // {
  //   "array": [{ "startdate": "2019/07/21", "enddate": "2019/07/22" }, { "startdate": "2019/07/22", "enddate": "2019/07/23" }, { "startdate": "2019/07/23", "enddate": "2019/07/24" }, { "startdate": "2019/07/24", "enddate": "2019/07/25" }, { "startdate": "2019/07/25", "enddate": "2019/07/26" }, { "startdate": "2019/07/26", "enddate": "2019/07/27" }, { "startdate": "2019/07/27", "enddate": "2019/07/28" }],



  //   "type": 0
  // }

  // this.appService.getGraph(data).subscribe((res: any) => {
  //   this.graphData = res;

  // this.ChartArrOne = res;
  // this.user_orders = res.user_orders;
  // console.log(this.user_orders);
  // debugger;
  // this.vendor_orders = res.vendor_orders;



  // this.userCount = res.json().data.users;
  // })




  console.log(this.ChartArrOne);


  console.log(this.user_orders);


  console.log(JSON.stringify(this.user_orders));

  console.log();

  localStorage.setItem('UO', JSON.stringify(this.user_orders));


  localStorage.setItem('VO', JSON.stringify(this.vendor_orders));


  console.log(JSON.parse(localStorage.getItem('UO')));
  console.log(this.vendor_orders);


  console.log(JSON.parse(localStorage.getItem('WeekChart_user_orders')));


  this.localTestUO = JSON.parse(localStorage.getItem('UO'));

  this.localTestVO = JSON.parse(localStorage.getItem('VO'));
  console.log(JSON.parse(localStorage.getItem('WeekChart_vendor_orders')));


}



public lineChartData: ChartDataSets[] = [
  // {
  //   data:
  //     JSON.parse(localStorage.getItem('UO'))
  //   , label: 'User Orders'
  // },
  // {
  //   data:
  //     JSON.parse(localStorage.getItem('VO'))
  //   , label: 'Vendor Orders'
  // },
  {
    data:
      JSON.parse(localStorage.getItem('WeekChart_user_orders'))
    , label: 'WeekChart_user_orders'
  },
  {
    data:
      JSON.parse(localStorage.getItem('WeekChart_vendor_orders'))
    , label: 'WeekChart_vendor_orders'
  },

];
public lineChartLabels: Label[] =
  ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
public lineChartOptions: (ChartOptions & { annotation: any }) = {
  responsive: true,
};
public lineChartColors: Color[] = [
  {
    borderColor: 'black',
    backgroundColor: 'rgba(22,33,55,0.5)',
  },
];
public lineChartLegend = true;
public lineChartType = 'line';
public lineChartPlugins = [];




}
